import React from 'react';
interface PDFViewProps {
    pdfLink: string;
}
declare const PDFView: React.FC<PDFViewProps>;
export default PDFView;
//# sourceMappingURL=pdfVeiwer.d.ts.map