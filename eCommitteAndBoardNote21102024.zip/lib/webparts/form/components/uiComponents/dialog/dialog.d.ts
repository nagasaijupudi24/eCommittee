import * as React from "react";
interface MyDialogProps {
    hidden: boolean;
    handleDialogBox: () => void;
    data: any;
}
declare const MyDialog: React.FC<MyDialogProps>;
export default MyDialog;
//# sourceMappingURL=dialog.d.ts.map