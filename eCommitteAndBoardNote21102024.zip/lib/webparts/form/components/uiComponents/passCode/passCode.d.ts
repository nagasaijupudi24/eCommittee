import * as React from "react";
import "@pnp/sp/files";
import "@pnp/sp/site-users/web";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files/web";
export interface IPasscodeModalProps {
    sp: any;
    user: any;
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    createPasscodeUrl: string;
}
export interface IPasscodeModalState {
    userId: any;
    passcode: string;
    errorMessage: string;
    userPasscodes: Array<{
        username: string;
        passcode: string;
    }>;
    userEmail: string;
    isCreating: boolean;
    isPasswordVisible: boolean;
}
export default class PasscodeModal extends React.Component<IPasscodeModalProps, IPasscodeModalState> {
    private key;
    private iv;
    constructor(props: IPasscodeModalProps);
    componentDidMount(): Promise<void>;
    private getUserIdByEmail;
    private fetchStoredPasscodes;
    private checkUserPasscode;
    private onPasscodeChange;
    private togglePasswordVisibility;
    private decrypt;
    private validatePasscode;
    private redirectToCreatePasscode;
    render(): React.ReactElement<IPasscodeModalProps>;
}
//# sourceMappingURL=passCode.d.ts.map