import * as React from 'react';
import { IPDFViewerProps } from './IPDFViewerProps';
declare const PDFViewer: React.FC<IPDFViewerProps>;
export default PDFViewer;
//# sourceMappingURL=pdfDist.d.ts.map