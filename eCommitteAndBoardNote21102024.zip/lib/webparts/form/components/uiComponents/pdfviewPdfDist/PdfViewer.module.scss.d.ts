declare const styles: {
    pdfViewer: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
    pdfContainer: string;
    pdfbutton: string;
};
export default styles;
//# sourceMappingURL=PdfViewer.module.scss.d.ts.map