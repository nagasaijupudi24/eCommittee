import * as React from 'react';
import 'pdfjs-dist/build/pdf.worker.mjs';
export interface IViewPdfProps {
    pdfUrl: string;
}
declare const IbViewPdf: React.FC<IViewPdfProps>;
export default IbViewPdf;
//# sourceMappingURL=newPDFIB.d.ts.map