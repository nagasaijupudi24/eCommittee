import * as React from 'react';
declare const GistDocsConfirmation: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
    handleConfirmatBtn: any;
}>;
export default GistDocsConfirmation;
//# sourceMappingURL=gistDocsConfirmationDialog.d.ts.map