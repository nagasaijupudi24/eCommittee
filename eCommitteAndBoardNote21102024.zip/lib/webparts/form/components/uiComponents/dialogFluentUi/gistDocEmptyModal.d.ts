import * as React from 'react';
declare const GistDocEmptyModal: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default GistDocEmptyModal;
//# sourceMappingURL=gistDocEmptyModal.d.ts.map