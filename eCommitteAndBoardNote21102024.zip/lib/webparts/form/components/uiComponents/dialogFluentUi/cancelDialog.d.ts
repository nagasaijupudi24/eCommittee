import * as React from 'react';
interface ICancelConfirmationDialogProps {
    hidden: boolean;
    onConfirm: () => void;
    onCancel: () => void;
}
declare const CancelConfirmationDialog: React.FC<ICancelConfirmationDialogProps>;
export default CancelConfirmationDialog;
//# sourceMappingURL=cancelDialog.d.ts.map