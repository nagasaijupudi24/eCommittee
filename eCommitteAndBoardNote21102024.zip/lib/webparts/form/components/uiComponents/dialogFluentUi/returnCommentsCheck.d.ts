import * as React from 'react';
declare const ReturnBtnCommentCheckDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default ReturnBtnCommentCheckDialog;
//# sourceMappingURL=returnCommentsCheck.d.ts.map