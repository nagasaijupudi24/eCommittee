import * as React from 'react';
declare const CommentsMandatoryDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default CommentsMandatoryDialog;
//# sourceMappingURL=generalCommentsMandiatoryDialog.d.ts.map