import * as React from "react";
interface IDialogProps {
    hiddenProp: any;
    dialogDetails: any;
    sp: any;
    context: any;
    fetchAnydata: any;
    fetchReferData: any;
}
export declare const DialogBlockingExample: React.FunctionComponent<IDialogProps>;
export {};
//# sourceMappingURL=dialogFluentUi.d.ts.map