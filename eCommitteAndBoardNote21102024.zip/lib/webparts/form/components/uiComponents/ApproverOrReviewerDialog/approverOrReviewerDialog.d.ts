import * as React from "react";
interface MyModalProps {
    hidden: boolean;
    handleDialogBox: () => void;
}
declare const ApproverOrReviewerModal: React.FC<MyModalProps>;
export default ApproverOrReviewerModal;
//# sourceMappingURL=approverOrReviewerDialog.d.ts.map