import * as React from "react";
interface IGridRow {
    id: string;
    pageNum: string;
    page: string;
    comment: string;
    commentedBy: string;
    commentedByEmail: any;
    commentsFrom: any;
}
interface IGridProps {
    data: any;
    currentUserDetails: any;
    type: any;
    handleCommentDataFuntion: (data: any, action: any, id?: any) => void;
}
interface IGridState {
    isVisibleAlter: any;
    pageNumValue: string;
    pageValue: string;
    commentValue: string;
    rowsData: IGridRow[];
    editRowId: string;
    isDialogOpen: boolean;
    isEditMode: boolean;
}
export default class GeneralCommentsFluentUIGrid extends React.Component<IGridProps, IGridState> {
    constructor(props: IGridProps);
    private _getCurentUserComment;
    private handleInputChange;
    private handleAddBtn;
    private handleSave;
    private handleAddNewComment;
    private handleEdit;
    private handleSaveBtn;
    private handleDelete;
    private closeDialog;
    render(): React.ReactElement<any>;
}
export {};
//# sourceMappingURL=generalComment.d.ts.map