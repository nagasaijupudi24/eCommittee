declare const FileAttachmentTable: (props: any) => JSX.Element;
export default FileAttachmentTable;
//# sourceMappingURL=fileAttatchmentsTable.d.ts.map