import * as React from 'react';
import '@progress/kendo-theme-default/dist/all.css';
interface IPerson {
    id: number;
    name: string;
}
interface IPeoplePickerState {
    selectedPeople: IPerson[];
}
declare class PeoplePicker extends React.Component<{}, IPeoplePickerState> {
    constructor(props: {});
    handleChange(event: any): void;
    render(): JSX.Element;
}
export default PeoplePicker;
//# sourceMappingURL=peoplePickerInKendo.d.ts.map