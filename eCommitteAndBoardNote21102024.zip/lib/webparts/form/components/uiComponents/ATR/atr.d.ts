import * as React from 'react';
interface IATRAssigneeProps {
    gridData: any;
    updategirdData: any;
    commentsData: any;
    sp: any;
    context: any;
    atrCreatorsList: any;
    artCommnetsGridData: any;
    deletedGridData: any;
}
interface IATRAssigneeState {
    tableData: any;
    selectedUsers: any;
    currentRowKey: any;
    selectedStatus: any;
    selectedValue: any;
    commentsData: any;
}
export declare class ATRAssignee extends React.Component<IATRAssigneeProps, IATRAssigneeState> {
    constructor(props: IATRAssigneeProps);
    private _updateStatusOptions;
    private columns;
    private handleRowClick;
    private handleDeleteRow;
    _getDetailsFromPeoplePicker: () => any;
    _getDetailsFromPeoplePickerData: (data: any, type: any) => any;
    render(): React.ReactElement<IATRAssigneeProps>;
}
export {};
//# sourceMappingURL=atr.d.ts.map