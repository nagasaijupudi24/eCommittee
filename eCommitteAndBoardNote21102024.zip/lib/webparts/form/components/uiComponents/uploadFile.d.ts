import * as React from 'react';
export interface IUploadFileProps {
    typeOfDoc: string;
    onChange: (files: File[] | null, typeOfDoc: string) => void;
    accept?: string;
    maxFileSizeMB: number;
    multiple: boolean;
    maxTotalSizeMB?: number;
    data: File[];
}
interface IFileWithError {
    file: File;
    error: string | null;
}
interface IUploadFileState {
    selectedFiles: IFileWithError[];
    cummError: string | null;
}
export default class UploadFileComponent extends React.Component<IUploadFileProps, IUploadFileState> {
    private fileInputRef;
    constructor(props: IUploadFileProps);
    componentDidMount(): void;
    componentDidUpdate(prevProps: IUploadFileProps): void;
    private isFileNameValid;
    private validateFiles;
    private handleFileChange;
    private handleDeleteFile;
    render(): React.ReactElement<IUploadFileProps>;
}
export {};
//# sourceMappingURL=uploadFile.d.ts.map