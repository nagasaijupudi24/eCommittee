import React from 'react';
interface ExpandableListProps {
    title: string;
    content: {
        key: string;
        value: string;
    }[];
}
declare const ExpandableList: React.FC<ExpandableListProps>;
export default ExpandableList;
//# sourceMappingURL=expandableHeader.d.ts.map