import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
export default function PSPDFKitViewer(props: IPSPDFKitViewerProps): JSX.Element;
export interface IPSPDFKitViewerProps {
    documentURL: string;
    sp: any;
}
//# sourceMappingURL=psdPDF.d.ts.map