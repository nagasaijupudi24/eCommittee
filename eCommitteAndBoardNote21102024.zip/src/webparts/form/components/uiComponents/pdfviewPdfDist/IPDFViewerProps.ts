export interface IPDFViewerProps {
    pdfPath: string;
    zoomLevel?: number;
  }
  