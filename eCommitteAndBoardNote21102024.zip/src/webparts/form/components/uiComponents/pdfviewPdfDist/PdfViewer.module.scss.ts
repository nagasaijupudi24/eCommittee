/* tslint:disable */
require("./PdfViewer.module.css");
const styles = {
  pdfViewer: 'pdfViewer_d76e889a',
  teams: 'teams_d76e889a',
  welcome: 'welcome_d76e889a',
  welcomeImage: 'welcomeImage_d76e889a',
  links: 'links_d76e889a',
  pdfContainer: 'pdfContainer_d76e889a',
  pdfbutton: 'pdfbutton_d76e889a'
};

export default styles;
/* tslint:enable */