/* tslint:disable */
require("./Form.module.css");
const styles = {
  form: 'form_d2664a4e',
  welcome: 'welcome_d2664a4e',
  welcomeImage: 'welcomeImage_d2664a4e',
  links: 'links_d2664a4e',
  generalSectionMainContainer: 'generalSectionMainContainer_d2664a4e',
  generalSection: 'generalSection_d2664a4e',
  halfWidth: 'halfWidth_d2664a4e',
  generalSectionContainer1: 'generalSectionContainer1_d2664a4e',
  generalSectionApproverDetails: 'generalSectionApproverDetails_d2664a4e',
  approverDetailsSection: 'approverDetailsSection_d2664a4e',
  headerContainer: 'headerContainer_d2664a4e',
  headers: 'headers_d2664a4e',
  commonProperties: 'commonProperties_d2664a4e',
  responsiveTitle: 'responsiveTitle_d2664a4e',
  noteHeader: 'noteHeader_d2664a4e',
  noteTitle: 'noteTitle_d2664a4e',
  commonBtn: 'commonBtn_d2664a4e',
  commonBtn1: 'commonBtn1_d2664a4e',
  commonBtn2: 'commonBtn2_d2664a4e',
  addBtn: 'addBtn_d2664a4e',
  message: 'message_d2664a4e',
  warning: 'warning_d2664a4e',
  label: 'label_d2664a4e',
  tableContainer: 'tableContainer_d2664a4e',
  fileInputContainers: 'fileInputContainers_d2664a4e',
  fileAttachementsUl: 'fileAttachementsUl_d2664a4e',
  basicLi: 'basicLi_d2664a4e',
  inputField: 'inputField_d2664a4e',
  attachementli: 'attachementli_d2664a4e',
  customFileUpload: 'customFileUpload_d2664a4e',
  viewForm: 'viewForm_d2664a4e',
  table: 'table_d2664a4e',
  pdfViewer: 'pdfViewer_d2664a4e',
  sectionContainer: 'sectionContainer_d2664a4e',
  header: 'header_d2664a4e',
  sectionText: 'sectionText_d2664a4e',
  chevronIcon: 'chevronIcon_d2664a4e'
};

export default styles;
/* tslint:enable */