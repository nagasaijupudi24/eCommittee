/// <reference types="react" />
declare const SimpleTable: (props: any) => JSX.Element;
export default SimpleTable;
//# sourceMappingURL=simpleTable.d.ts.map