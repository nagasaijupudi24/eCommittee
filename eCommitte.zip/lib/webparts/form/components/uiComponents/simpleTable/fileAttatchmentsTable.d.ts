/// <reference types="react" />
declare const FileAttatchmentTable: (props: any) => JSX.Element;
export default FileAttatchmentTable;
//# sourceMappingURL=fileAttatchmentsTable.d.ts.map