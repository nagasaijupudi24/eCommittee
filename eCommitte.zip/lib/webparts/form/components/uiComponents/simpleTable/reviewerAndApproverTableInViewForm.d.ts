/// <reference types="react" />
declare const ApproverAndReviewerTableInViewForm: (props: any) => JSX.Element;
export default ApproverAndReviewerTableInViewForm;
//# sourceMappingURL=reviewerAndApproverTableInViewForm.d.ts.map