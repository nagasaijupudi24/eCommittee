/// <reference types="react" />
declare const CommentsLogTable: (props: any) => JSX.Element;
export default CommentsLogTable;
//# sourceMappingURL=commentsTable%20copy%202.d.ts.map