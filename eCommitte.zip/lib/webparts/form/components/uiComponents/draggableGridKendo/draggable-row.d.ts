/// <reference types="react" />
import { GridRowProps } from '@progress/kendo-react-grid';
interface DraggableRowProps extends GridRowProps {
    elementProps: any;
}
export declare const DraggableRow: (props: DraggableRowProps) => JSX.Element;
export {};
//# sourceMappingURL=draggable-row.d.ts.map