/// <reference types="react" />
import { GridCellProps } from '@progress/kendo-react-grid';
export declare const DragHandleCell: (props: GridCellProps) => JSX.Element;
//# sourceMappingURL=drag-handle-cell.d.ts.map