import React, { ReactNode } from 'react';
import { SPFI } from "@pnp/sp";
import { WebPartContext } from "@microsoft/sp-webpart-base";
interface ISPDataContext {
    listItems: any[];
    setListItems: React.Dispatch<React.SetStateAction<any[]>>;
    context: WebPartContext | undefined;
}
export declare const useSPData: () => ISPDataContext;
export declare const SPDataProvider: React.FC<{
    sp: SPFI;
    context: WebPartContext;
    children: ReactNode;
}>;
export {};
//# sourceMappingURL=SPDataContext.d.ts.map