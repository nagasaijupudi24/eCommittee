import * as React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
interface IPnPPeoplePickerProps {
    context: WebPartContext;
}
interface IPnPPeoplePickerState {
    addUsers: string[];
    selectedPeople: string[];
}
export default class PnPPeoplePicker2 extends React.Component<IPnPPeoplePickerProps, IPnPPeoplePickerState> {
    constructor(props: IPnPPeoplePickerProps, state: IPnPPeoplePickerState);
    private _getPeoplePickerItems;
    private _clearPeoplePicker;
    render(): React.ReactElement<IPnPPeoplePickerProps>;
}
export {};
//# sourceMappingURL=people.d.ts.map