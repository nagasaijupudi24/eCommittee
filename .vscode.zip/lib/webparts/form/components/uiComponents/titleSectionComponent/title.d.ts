import * as React from 'react';
interface TitleProps {
    formType: string;
    statusOfRequest: string;
    propPaneformType: any;
}
declare const Title: React.FC<TitleProps>;
export default Title;
//# sourceMappingURL=title.d.ts.map