import * as React from "react";
interface MyDialogProps {
    hidden: boolean;
    handleDialogBox: () => void;
}
declare const ApproverOrReviewerDialog: React.FC<MyDialogProps>;
export default ApproverOrReviewerDialog;
//# sourceMappingURL=approverOrReviewerDialog.d.ts.map