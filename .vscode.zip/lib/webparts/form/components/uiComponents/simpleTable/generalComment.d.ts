import * as React from "react";
interface IGridState {
    pageNumValue: string;
    pageValue: string;
    commentValue: string;
    rowsData: any;
    editState: boolean;
    id: any;
    editPageNumValue: string;
    editPageValue: string;
    editCommentValue: string;
}
export default class GeneralCommentsFluentUIGrid extends React.Component<any, IGridState> {
    constructor(props: any);
    _getCurentUserComment: () => any;
    handleInputElement: (event: any, type?: any, id?: any) => void;
    handleAddBtn: (event: any) => void;
    handleSaveBtn: (event: any) => void;
    _getValue: (type?: any) => any;
    private handleDelete;
    render(): React.ReactElement<any>;
}
export {};
//# sourceMappingURL=generalComment.d.ts.map