import * as React from 'react';
import { Product } from './shared-gd-interfaces.tsx';
declare type ContextProps = {
    reorder: (dataItem: Product, direction: 'before' | 'after' | null) => void;
    dragStart: (dataItem: Product) => void;
};
export declare const ReorderContext: React.Context<ContextProps>;
declare const DraggableTable: (props: any) => JSX.Element;
export default DraggableTable;
//# sourceMappingURL=draggableGridKendo.d.ts.map