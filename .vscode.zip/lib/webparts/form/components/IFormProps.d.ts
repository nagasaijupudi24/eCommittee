import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPFI } from "@pnp/sp";
export interface IFormProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    sp: SPFI;
    context: WebPartContext;
    listId: any;
    libraryId: any;
    formType: any;
}
//# sourceMappingURL=IFormProps.d.ts.map