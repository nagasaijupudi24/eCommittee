import * as React from 'react';
export interface IPdfViewerProps {
    pdfUrl: string;
}
declare const PdfViewer: React.FC<IPdfViewerProps>;
export default PdfViewer;
//# sourceMappingURL=pdfreact.d.ts.map